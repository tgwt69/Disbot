"""
Rate limiting utilities for the Discord SelfBot
Prevents excessive API usage and potential detection
"""

import time
import asyncio
from collections import defaultdict, deque
from utils.logger import log_warning, log_debug

class RateLimiter:
    """Advanced rate limiter with per-user tracking"""
    
    def __init__(self, max_commands_per_minute=30, burst_limit=5):
        self.max_commands_per_minute = max_commands_per_minute
        self.burst_limit = burst_limit
        self.user_commands = defaultdict(lambda: deque())
        self.user_burst = defaultdict(int)
        self.user_last_reset = defaultdict(float)
        
    async def check_rate_limit(self, user_id):
        """Check if user is within rate limits"""
        now = time.time()
        
        # Reset burst counter every minute
        if now - self.user_last_reset[user_id] >= 60:
            self.user_burst[user_id] = 0
            self.user_last_reset[user_id] = now
        
        # Check burst limit
        if self.user_burst[user_id] >= self.burst_limit:
            log_warning(f"Burst limit exceeded for user {user_id}")
            await asyncio.sleep(1)  # Brief delay
            return False
        
        # Clean old commands (older than 1 minute)
        commands = self.user_commands[user_id]
        while commands and now - commands[0] > 60:
            commands.popleft()
        
        # Check rate limit
        if len(commands) >= self.max_commands_per_minute:
            log_warning(f"Rate limit exceeded for user {user_id}")
            return False
        
        # Record this command
        commands.append(now)
        self.user_burst[user_id] += 1
        
        log_debug(f"Rate limit check passed for user {user_id} ({len(commands)}/{self.max_commands_per_minute})")
        return True
    
    def reset_user_limits(self, user_id):
        """Reset rate limits for a specific user"""
        if user_id in self.user_commands:
            self.user_commands[user_id].clear()
        self.user_burst[user_id] = 0
        self.user_last_reset[user_id] = time.time()
    
    def get_user_stats(self, user_id):
        """Get rate limit statistics for a user"""
        now = time.time()
        commands = self.user_commands[user_id]
        
        # Clean old commands
        while commands and now - commands[0] > 60:
            commands.popleft()
        
        return {
            "commands_this_minute": len(commands),
            "max_commands_per_minute": self.max_commands_per_minute,
            "burst_used": self.user_burst[user_id],
            "burst_limit": self.burst_limit,
            "time_until_reset": max(0, 60 - (now - self.user_last_reset[user_id]))
        }

class DiscordRateLimiter:
    """Rate limiter specific to Discord API endpoints"""
    
    def __init__(self):
        self.endpoint_buckets = defaultdict(lambda: {"remaining": 5, "reset_time": 0})
        self.global_bucket = {"remaining": 50, "reset_time": 0}
    
    async def wait_for_rate_limit(self, endpoint="default"):
        """Wait if rate limited for a specific endpoint"""
        now = time.time()
        
        # Check global rate limit
        if now < self.global_bucket["reset_time"]:
            wait_time = self.global_bucket["reset_time"] - now
            log_warning(f"Global rate limit hit, waiting {wait_time:.2f}s")
            await asyncio.sleep(wait_time)
        
        # Check endpoint-specific rate limit
        bucket = self.endpoint_buckets[endpoint]
        if now < bucket["reset_time"] and bucket["remaining"] <= 0:
            wait_time = bucket["reset_time"] - now
            log_warning(f"Endpoint '{endpoint}' rate limited, waiting {wait_time:.2f}s")
            await asyncio.sleep(wait_time)
        
        # Update bucket
        if now >= bucket["reset_time"]:
            bucket["remaining"] = 5
            bucket["reset_time"] = now + 1  # Reset in 1 second
        
        bucket["remaining"] -= 1
    
    def update_from_response_headers(self, headers, endpoint="default"):
        """Update rate limits from Discord response headers"""
        try:
            bucket = self.endpoint_buckets[endpoint]
            
            if "X-RateLimit-Remaining" in headers:
                bucket["remaining"] = int(headers["X-RateLimit-Remaining"])
            
            if "X-RateLimit-Reset" in headers:
                bucket["reset_time"] = float(headers["X-RateLimit-Reset"])
            
            # Check for global rate limit
            if "X-RateLimit-Global" in headers:
                if "Retry-After" in headers:
                    retry_after = float(headers["Retry-After"]) / 1000  # Convert ms to seconds
                    self.global_bucket["reset_time"] = time.time() + retry_after
                    self.global_bucket["remaining"] = 0
        
        except (ValueError, KeyError) as e:
            log_warning(f"Failed to parse rate limit headers: {e}")

# Global rate limiter instances
_rate_limiter = None
_discord_rate_limiter = None

def get_rate_limiter():
    """Get the global rate limiter instance"""
    global _rate_limiter
    if _rate_limiter is None:
        _rate_limiter = RateLimiter()
    return _rate_limiter

def get_discord_rate_limiter():
    """Get the Discord API rate limiter instance"""
    global _discord_rate_limiter
    if _discord_rate_limiter is None:
        _discord_rate_limiter = DiscordRateLimiter()
    return _discord_rate_limiter
