"""
Logging utilities for the Discord SelfBot
Provides structured logging with both file and console output
"""

import logging
import os
import datetime
from colorama import Fore

# Color constants
y = Fore.LIGHTYELLOW_EX
b = Fore.LIGHTBLUE_EX
w = Fore.LIGHTWHITE_EX
g = Fore.LIGHTGREEN_EX
r = Fore.LIGHTRED_EX

def setup_logger(name="selfbot", level=logging.INFO, log_file="selfbot.log"):
    """Setup a structured logger with file and console handlers"""
    
    # Create logs directory if it doesn't exist
    os.makedirs("logs", exist_ok=True)
    
    # Create logger
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    # Prevent duplicate handlers
    if logger.handlers:
        return logger
    
    # Create formatters
    file_formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    console_formatter = logging.Formatter(
        f'{y}[%(asctime)s]{w} %(levelname)s: %(message)s',
        datefmt='%H:%M:%S'
    )
    
    # File handler
    file_handler = logging.FileHandler(
        os.path.join("logs", log_file),
        encoding='utf-8'
    )
    file_handler.setLevel(level)
    file_handler.setFormatter(file_formatter)
    
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(level)
    console_handler.setFormatter(console_formatter)
    
    # Add handlers to logger
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    
    return logger

# Global logger instance
_logger = None

def get_logger():
    """Get the global logger instance"""
    global _logger
    if _logger is None:
        _logger = setup_logger()
    return _logger

def log_info(message):
    """Log an info message"""
    get_logger().info(message)

def log_warning(message):
    """Log a warning message"""
    get_logger().warning(message)

def log_error(message):
    """Log an error message"""
    get_logger().error(message)

def log_debug(message):
    """Log a debug message"""
    get_logger().debug(message)

def log_critical(message):
    """Log a critical message"""
    get_logger().critical(message)

class CommandLogger:
    """Logger specifically for command usage tracking"""
    
    def __init__(self):
        self.logger = setup_logger("commands", log_file="commands.log")
    
    def log_command(self, user_id, username, command, guild_id=None, channel_id=None):
        """Log command usage"""
        context = f"Guild: {guild_id}, Channel: {channel_id}" if guild_id else "DM"
        self.logger.info(f"User {username} ({user_id}) used command '{command}' in {context}")
    
    def log_command_error(self, user_id, username, command, error):
        """Log command errors"""
        self.logger.error(f"Command '{command}' failed for {username} ({user_id}): {error}")

# Global command logger
_command_logger = None

def get_command_logger():
    """Get the global command logger instance"""
    global _command_logger
    if _command_logger is None:
        _command_logger = CommandLogger()
    return _command_logger
