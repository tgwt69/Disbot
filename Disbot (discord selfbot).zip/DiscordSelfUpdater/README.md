# Discord SelfBot v3.0 - 2025 Edition

[![Python Version](https://img.shields.io/badge/Python-3.8%2B-blue.svg)](https://www.python.org/downloads/)
[![discord.py-self](https://img.shields.io/badge/discord.py--self-2.0.1-green.svg)](https://pypi.org/project/discord.py-self/)
[![License](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Platform](https://img.shields.io/badge/Platform-Windows%20%7C%20Linux%20%7C%20macOS-lightgrey.svg)](#)

A modernized Discord selfbot application updated for 2025 compatibility using the latest discord.py-self library. This is a complete rewrite of the original AstraaDev selfbot with enhanced features, improved error handling, and 2025 API compatibility.

## ⚠️ Disclaimer

**Automating user accounts is against Discord's Terms of Service.** This project is for educational purposes only. Use at your own risk. The developers are not responsible for any account actions taken by Discord.

## ✨ Features

### Core Features
- **Modern Architecture**: Built with discord.py-self 2.0.1 (latest 2025 release)
- **Enhanced Error Handling**: Comprehensive error management and logging
- **Rate Limiting**: Advanced rate limiting to avoid API abuse
- **Cross-Platform**: Works on Windows, Linux, and macOS
- **Modular Design**: Clean, organized code structure with separate command modules

### Command Categories

#### 🔧 Core Commands
- `help` - Display comprehensive help information
- `uptime` - Show bot uptime statistics
- `ping` - Display latency information
- `changeprefix` - Change command prefix
- `shutdown` - Gracefully stop the selfbot
- `astraa` - Developer information and links

#### 🛠️ Utility Commands
- `geoip <ip>` - IP geolocation lookup
- `tts <text>` - Text-to-speech conversion
- `qr <text>` - QR code generation
- `pingweb <url>` - Website status checker
- `gentoken` - Generate fake Discord tokens
- `reverse <text>` - Reverse text
- `ascii <text>` - Convert text to ASCII art
- `hypesquad <house>` - Change HypeSquad badge
- `nitro` - Generate fake Nitro codes

#### 🛡️ Moderation Commands
- `purge <amount>` - Delete messages in bulk
- `clear` - Clear channel messages
- `cleardm <amount>` - Clear DM messages
- `spam <amount> <message>` - Send multiple messages
- `quickdelete <message>` - Send and auto-delete message
- `whremove <webhook_url>` - Remove webhooks

#### 🎮 Fun Commands
- `playing/watching <status>` - Set activity status
- `stopactivity` - Clear activity status
- `dick <@user>` - Random size generator (fun)
- `minesweeper <width> <height>` - Generate minesweeper game
- `leetpeek <text>` - Convert to leet speak
- `airplane` - Send airplane ASCII art
- `firstmessage` - Get first message in channel

#### 📊 Server Commands
- `fetchmembers` - Get server member list
- `dmall <message>` - DM all server members
- `sendall <message>` - Send to all channels
- `guildinfo` - Server information
- `guildrename <name>` - Rename server
- `guildicon/guildbanner` - Get server assets
- `usericon <@user>` - Get user avatar
- `tokeninfo <token>` - Analyze Discord tokens

#### 🤖 Automation Commands
- `afk <ON|OFF> [message]` - AFK mode with auto-responses
- `autoreply <ON|OFF> [target]` - Auto-reply to messages
- `copycat <ON|OFF> <@user>` - Mirror user messages
- `remoteuser <ADD|REMOVE|LIST> [@user]` - Manage remote control
- `edit <message>` - Send message with edited tag

## 🚀 Installation

### Automated Setup

#### Windows
```cmd
git clone https://github.com/AstraaDev/Discord-SelfBot.git
cd Discord-SelfBot
setup.bat
