# Discord SelfBot v3.0 - 2025 Edition

## Overview

This is a modernized Discord selfbot application built with Python 3.8+ and discord.py-self 2.0.1. The project is designed as an educational tool demonstrating automated Discord user interactions through a comprehensive command system. The application features a modular architecture with separate command categories, advanced rate limiting, and comprehensive logging capabilities.

## System Architecture

### Core Architecture
- **Language**: Python 3.8+ with asyncio for concurrent operations
- **Discord Library**: discord.py-self 2.0.1 (latest 2025 release)
- **Design Pattern**: Command-based architecture using discord.py's Cogs system
- **Configuration**: JSON-based configuration with runtime modification support
- **Cross-Platform**: Designed to work on Windows, Linux, and macOS

### Modular Structure
The application follows a clean separation of concerns with dedicated modules:
- **Core Commands**: Basic bot functionality (help, uptime, configuration)
- **Utility Commands**: Tools and generators (IP lookup, QR codes, TTS)
- **Moderation Commands**: Message management and server administration
- **Fun Commands**: Entertainment features and status management
- **Automation Commands**: AFK mode, autoreply, and copycat functionality

## Key Components

### 1. Main Application (`main.py`)
- Central SelfBot class handling initialization and configuration
- Integration point for all command modules
- Startup banner and version management
- Error handling and graceful shutdown

### 2. Command System
**Core Commands** (`commands/core.py`):
- Help system with comprehensive command listings
- Prefix management and configuration
- Uptime tracking and system information
- Remote user management

**Utility Commands** (`commands/utility.py`):
- IP geolocation lookup using ip-api.com
- QR code generation with PIL
- Text-to-speech using Google TTS
- ASCII art generation with pyfiglet

**Moderation Commands** (`commands/moderation.py`):
- Bulk message deletion (purge functionality)
- Channel and DM message management
- Webhook management
- Spam utilities with safety checks

**Automation Commands** (`commands/automation.py`):
- AFK mode with custom messages
- Autoreply system for specific channels/users
- Copycat functionality for mimicking users

### 3. Utilities System
**Logger** (`utils/logger.py`):
- Structured logging with file and console output
- Color-coded console messages using colorama
- Separate log files in dedicated logs directory
- Command execution tracking

**Rate Limiter** (`utils/rate_limiter.py`):
- Per-user command tracking with deque-based storage
- Configurable rate limits (default: 30 commands/minute)
- Burst protection (default: 5 commands)
- Automatic cleanup of old command records

### 4. Configuration Management
**Config File** (`config/config.json`):
- User token storage
- Command prefix customization
- Feature toggles for automation systems
- Rate limiting configuration
- Security settings and restrictions

## Data Flow

### Command Processing Flow
1. **Message Reception**: Discord message events are captured
2. **Prefix Validation**: Messages are checked against configured prefix
3. **Rate Limiting**: User commands are validated against rate limits
4. **Command Routing**: Commands are routed to appropriate Cog modules
5. **Execution**: Command logic is executed with error handling
6. **Logging**: Command execution is logged for audit purposes
7. **Cleanup**: Messages may be auto-deleted based on configuration

### Configuration Flow
1. **Startup**: Configuration is loaded from JSON file
2. **Runtime Updates**: Commands can modify configuration in memory
3. **Persistence**: Configuration changes are saved back to JSON file
4. **Validation**: Configuration values are validated before application

## External Dependencies

### Core Dependencies
- **discord.py-self**: 2.0.1 - Discord API interaction
- **requests**: HTTP requests for web services
- **colorama**: Cross-platform colored terminal output

### Utility Dependencies
- **gtts**: Google Text-to-Speech conversion
- **qrcode[pil]**: QR code generation with PIL support
- **pyfiglet**: ASCII art text generation

### Development Tools
- **setup.py**: Automated installation and dependency management
- Platform detection and Python version validation

## Deployment Strategy

### Installation Process
1. **Python Version Check**: Validates Python 3.8+ requirement
2. **Dependency Installation**: Automated pip installation of required packages
3. **Configuration Setup**: Interactive token configuration
4. **Directory Structure**: Automatic creation of logs and config directories

### Runtime Requirements
- **Token Configuration**: User must provide Discord user token
- **Permission Considerations**: Some commands require specific Discord permissions
- **Rate Limiting**: Built-in protection against API abuse
- **Logging**: Comprehensive logging for debugging and monitoring

### Security Considerations
- **Safe Mode**: Optional restricted command execution
- **Guild Restrictions**: Ability to limit bot to specific servers
- **Auto-deletion**: Optional automatic command deletion
- **Token Protection**: Configuration file should be secured

## Changelog

### July 01, 2025 - Complete Modernization Update
- **MAJOR UPDATE**: Completely modernized Discord SelfBot for 2025 compatibility
- **Library Update**: Upgraded to discord.py-self 2.0.1 (latest 2025 release)
- **Architecture Overhaul**: Complete rewrite with modular command system
- **Enhanced Features**: Added comprehensive error handling, rate limiting, and logging
- **Cross-Platform**: Updated for Windows, Linux, and macOS compatibility
- **Security**: Added rate limiting and safety features to prevent API abuse
- **Documentation**: Complete README and setup documentation update
- **Automation**: Enhanced setup scripts for both Windows and Unix systems

### Technical Improvements Made:
- Removed incompatible Intents system (discord.py-self doesn't use standard Intents)
- Fixed async/await patterns for modern Python
- Updated event handling for 2025 Discord API compatibility
- Enhanced error handling and logging system
- Added comprehensive command categorization (Core, Utility, Moderation, Fun, Automation)
- Implemented advanced rate limiting to prevent detection
- Added modular architecture with separate command files
- Updated all dependencies to latest versions

## User Preferences

Preferred communication style: Simple, everyday language.