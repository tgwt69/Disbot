"""
Core commands for the Discord SelfBot
Includes help, configuration, and basic utility commands
"""

import discord
from discord.ext import commands
import datetime
import time
import json
import os
from utils.logger import log_info, log_error, get_command_logger

class CoreCommands(commands.Cog):
    """Core functionality commands"""
    
    def __init__(self, bot, config, selfbot_instance):
        self.bot = bot
        self.config = config
        self.selfbot = selfbot_instance
        self.command_logger = get_command_logger()
        self.start_time = datetime.datetime.now(datetime.timezone.utc)
    
    @commands.command(aliases=['h'])
    async def help(self, ctx):
        """Display help information"""
        await ctx.message.delete()
        
        prefix = self.config.get("prefix", "*")
        
        help_text = f"""
**Astraa SelfBot v3.0 | Prefix: `{prefix}`**\n
**Core Commands:**\n
> :gear: `{prefix}help` - Show this help message
> :wrench: `{prefix}changeprefix <prefix>` - Change the bot's prefix
> :x: `{prefix}shutdown` - Stop the selfbot
> :notepad_spiral: `{prefix}uptime` - Returns how long the selfbot has been running
> :closed_lock_with_key: `{prefix}remoteuser <ADD|REMOVE|LIST> [@user]` - Manage remote users
> :robot: `{prefix}copycat <ON|OFF> [@user]` - Toggle copycat mode for a user
> :pushpin: `{prefix}ping` - Returns the bot's latency
> :zzz: `{prefix}afk <ON|OFF> [message]` - Toggle AFK mode
> :tools: `{prefix}autoreply <ON|OFF> [channel|@user]` - Toggle autoreply
> :space_invader: `{prefix}astraa` - Show developer social networks\n
**Utility Commands:**\n
> :pushpin: `{prefix}pingweb <url>` - Ping a website and return status
> :gear: `{prefix}geoip <ip>` - Lookup IP geolocation
> :microphone: `{prefix}tts <text>` - Convert text to speech
> :hash: `{prefix}qr <text>` - Generate QR code
> :detective: `{prefix}hidemention <display> <hidden>` - Hide text in messages
> :arrows_counterclockwise: `{prefix}reverse <text>` - Reverse text
> :notepad_spiral: `{prefix}gentoken` - Generate fake Discord token
> :star: `{prefix}hypesquad <house>` - Change HypeSquad badge
> :dart: `{prefix}nitro` - Generate fake Nitro code"""
        
        await ctx.send(help_text)
        
        help_text2 = f"""
**Moderation Commands:**\n
> :broom: `{prefix}purge <amount>` - Delete messages
> :broom: `{prefix}clear` - Clear channel messages
> :broom: `{prefix}cleardm <amount>` - Clear DM messages
> :writing_hand: `{prefix}spam <amount> <message>` - Spam messages
> :tools: `{prefix}quickdelete <message>` - Send and delete message
> :hammer: `{prefix}whremove <webhook_url>` - Remove webhook\n
**Server Commands:**\n
> :busts_in_silhouette: `{prefix}fetchmembers` - Get server members
> :mega: `{prefix}dmall <message>` - DM all server members
> :mega: `{prefix}sendall <message>` - Send to all channels
> :scroll: `{prefix}firstmessage` - Get first message link
> :busts_in_silhouette: `{prefix}guildicon` - Get server icon
> :space_invader: `{prefix}usericon [@user]` - Get user avatar
> :star: `{prefix}guildbanner` - Get server banner
> :page_facing_up: `{prefix}tokeninfo <token>` - Analyze token
> :pager: `{prefix}guildinfo` - Get server information
> :memo: `{prefix}guildrename <name>` - Rename server\n
**Fun Commands:**\n
> :video_game: `{prefix}playing <status>` - Set playing status
> :tv: `{prefix}watching <status>` - Set watching status
> :x: `{prefix}stopactivity` - Clear activity status
> :art: `{prefix}ascii <text>` - Convert to ASCII art
> :airplane: `{prefix}airplane` - Send 9/11 copypasta
> :fire: `{prefix}dick [@user]` - Random size generator
> :bomb: `{prefix}minesweeper <width> <height>` - Generate minesweeper
> :robot: `{prefix}leetpeek <text>` - Convert to leet speak"""
        
        await ctx.send(help_text2)
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), "help", 
                                       ctx.guild.id if ctx.guild else None, ctx.channel.id)
    
    @commands.command()
    async def uptime(self, ctx):
        """Show bot uptime"""
        await ctx.message.delete()
        
        now = datetime.datetime.now(datetime.timezone.utc)
        delta = now - self.start_time
        hours, remainder = divmod(int(delta.total_seconds()), 3600)
        minutes, seconds = divmod(remainder, 60)
        days, hours = divmod(hours, 24)
        
        if days:
            time_format = "**{d}** days, **{h}** hours, **{m}** minutes, and **{s}** seconds."
        else:
            time_format = "**{h}** hours, **{m}** minutes, and **{s}** seconds."
        
        uptime_stamp = time_format.format(d=days, h=hours, m=minutes, s=seconds)
        await ctx.send(f"> **Uptime:** {uptime_stamp}")
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), "uptime")
    
    @commands.command()
    async def ping(self, ctx):
        """Show bot latency"""
        await ctx.message.delete()
        
        before = time.monotonic()
        message = await ctx.send("Pinging...")
        after = time.monotonic()
        
        latency = int((after - before) * 1000)
        websocket_latency = int(self.bot.latency * 1000)
        
        await message.edit(content=f"> **Ping:** `{latency}ms` | **WebSocket:** `{websocket_latency}ms`")
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), "ping")
    
    @commands.command(aliases=['astra'])
    async def astraa(self, ctx):
        """Show developer information"""
        await ctx.message.delete()
        
        prefix = self.config.get("prefix", "*")
        
        embed_text = f"""**Developer Information | Prefix: `{prefix}`**\n
> :computer: **GitHub Profile**
*https://github.com/AstraaDev*
> :robot: **SelfBot Repository**
*https://github.com/AstraaDev/Discord-SelfBot*
> :speech_balloon: **Discord Server**
*https://discord.gg/PKR7nM9j9U*
> :globe_with_meridians: **Website**
*https://astraadev.github.io/*\n
**SelfBot v3.0 - 2025 Edition**
*Updated for discord.py-self 2.0.1 compatibility*"""
        
        await ctx.send(embed_text)
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), "astraa")
    
    @commands.command()
    async def changeprefix(self, ctx, new_prefix: str = None):
        """Change the bot prefix"""
        await ctx.message.delete()
        
        if not new_prefix:
            await ctx.send("> **[ERROR]**: Please provide a new prefix\n> **Usage:** `changeprefix <new_prefix>`", delete_after=5)
            return
        
        if len(new_prefix) > 5:
            await ctx.send("> **[ERROR]**: Prefix must be 5 characters or less", delete_after=5)
            return
        
        old_prefix = self.config.get("prefix", "*")
        self.config["prefix"] = new_prefix
        self.selfbot.save_config()
        
        await ctx.send(f"> **Prefix changed** from `{old_prefix}` to `{new_prefix}`")
        log_info(f"Prefix changed from '{old_prefix}' to '{new_prefix}' by {ctx.author}")
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), f"changeprefix {new_prefix}")
    
    @commands.command()
    async def shutdown(self, ctx):
        """Shutdown the selfbot"""
        await ctx.message.delete()
        
        await ctx.send("> **SelfBot shutting down...** :wave:", delete_after=3)
        log_info(f"SelfBot shutdown initiated by {ctx.author}")
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), "shutdown")
        
        # Close the bot gracefully
        await self.bot.close()
    
    @commands.command()
    async def remoteuser(self, ctx, action: str = None, user: discord.User = None):
        """Manage remote users who can control the bot"""
        await ctx.message.delete()
        
        if not action:
            await ctx.send("> **[ERROR]**: Please specify an action\n> **Usage:** `remoteuser <ADD|REMOVE|LIST> [@user]`", delete_after=5)
            return
        
        action = action.upper()
        
        if action == "LIST":
            remote_users = self.config.get("remote-users", [])
            if not remote_users:
                await ctx.send("> **Remote Users:** None configured")
                return
            
            user_list = []
            for user_id in remote_users:
                try:
                    user_obj = self.bot.get_user(int(user_id))
                    if user_obj:
                        user_list.append(f"• {user_obj} (`{user_id}`)")
                    else:
                        user_list.append(f"• Unknown User (`{user_id}`)")
                except:
                    user_list.append(f"• Invalid ID (`{user_id}`)")
            
            await ctx.send(f"> **Remote Users:**\n" + "\n".join(user_list))
        
        elif action in ["ADD", "REMOVE"]:
            if not user:
                await ctx.send(f"> **[ERROR]**: Please mention a user to {action.lower()}\n> **Usage:** `remoteuser {action} @user`", delete_after=5)
                return
            
            remote_users = self.config.get("remote-users", [])
            user_id_str = str(user.id)
            
            if action == "ADD":
                if user_id_str in remote_users:
                    await ctx.send(f"> **{user}** is already a remote user", delete_after=5)
                    return
                
                remote_users.append(user_id_str)
                self.config["remote-users"] = remote_users
                self.selfbot.save_config()
                
                await ctx.send(f"> **{user}** added as remote user")
                log_info(f"Added {user} ({user.id}) as remote user")
            
            elif action == "REMOVE":
                if user_id_str not in remote_users:
                    await ctx.send(f"> **{user}** is not a remote user", delete_after=5)
                    return
                
                remote_users.remove(user_id_str)
                self.config["remote-users"] = remote_users
                self.selfbot.save_config()
                
                await ctx.send(f"> **{user}** removed from remote users")
                log_info(f"Removed {user} ({user.id}) from remote users")
        
        else:
            await ctx.send("> **[ERROR]**: Invalid action. Use `ADD`, `REMOVE`, or `LIST`", delete_after=5)
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), f"remoteuser {action}")
