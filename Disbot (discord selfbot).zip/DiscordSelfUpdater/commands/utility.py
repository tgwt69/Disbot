"""
Utility commands for the Discord SelfBot
Includes various helpful tools and generators
"""

import discord
from discord.ext import commands
import requests
import random
import string
import io
import qrcode
from gtts import gTTS
import pyfiglet
from utils.logger import log_error, get_command_logger

class UtilityCommands(commands.Cog):
    """Utility and tool commands"""
    
    def __init__(self, bot, config, selfbot_instance):
        self.bot = bot
        self.config = config
        self.selfbot = selfbot_instance
        self.command_logger = get_command_logger()
    
    @commands.command()
    async def geoip(self, ctx, ip: str = None):
        """Lookup IP geolocation information"""
        await ctx.message.delete()
        
        if not ip:
            await ctx.send("> **[ERROR]**: Please provide an IP address\n> **Usage:** `geoip <ip_address>`", delete_after=5)
            return
        
        try:
            response = requests.get(f'http://ip-api.com/json/{ip}', timeout=10)
            response.raise_for_status()
            geo = response.json()
            
            if geo.get('status') == 'fail':
                await ctx.send(f"> **[ERROR]**: {geo.get('message', 'Invalid IP address')}", delete_after=5)
                return
            
            embed_text = f"""**IP Geolocation | {ip}**\n
> :pushpin: **IP Address**
*{geo.get('query', 'N/A')}*
> :globe_with_meridians: **Country - Region**
*{geo.get('country', 'N/A')} - {geo.get('regionName', 'N/A')}*
> :department_store: **City**
*{geo.get('city', 'N/A')} ({geo.get('zip', 'N/A')})*
> :map: **Coordinates**
*{geo.get('lat', 'N/A')}, {geo.get('lon', 'N/A')}*
> :satellite: **ISP**
*{geo.get('isp', 'N/A')}*
> :robot: **Organization**
*{geo.get('org', 'N/A')}*
> :alarm_clock: **Timezone**
*{geo.get('timezone', 'N/A')}*
> :electric_plug: **AS Number**
*{geo.get('as', 'N/A')}*"""
            
            await ctx.send(embed_text)
            
        except requests.RequestException as e:
            await ctx.send(f"> **[ERROR]**: Failed to lookup IP: {str(e)}", delete_after=5)
        except Exception as e:
            log_error(f"Unexpected error in geoip command: {e}")
            await ctx.send("> **[ERROR]**: An unexpected error occurred", delete_after=5)
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), f"geoip {ip}")
    
    @commands.command()
    async def tts(self, ctx, *, text: str = None):
        """Convert text to speech"""
        await ctx.message.delete()
        
        if not text:
            await ctx.send("> **[ERROR]**: Please provide text to convert\n> **Usage:** `tts <text>`", delete_after=5)
            return
        
        if len(text) > 500:
            await ctx.send("> **[ERROR]**: Text must be 500 characters or less", delete_after=5)
            return
        
        try:
            tts = gTTS(text=text.strip(), lang="en", slow=False)
            
            # Create audio file in memory
            audio_buffer = io.BytesIO()
            tts.write_to_fp(audio_buffer)
            audio_buffer.seek(0)
            
            # Send audio file
            filename = f"tts_{text[:20].replace(' ', '_')}.mp3"
            await ctx.send(file=discord.File(audio_buffer, filename))
            
        except Exception as e:
            log_error(f"TTS error: {e}")
            await ctx.send("> **[ERROR]**: Failed to generate speech", delete_after=5)
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), "tts")
    
    @commands.command(aliases=['qrcode'])
    async def qr(self, ctx, *, text: str = None):
        """Generate QR code from text"""
        await ctx.message.delete()
        
        if not text:
            text = "https://github.com/AstraaDev/Discord-SelfBot"
        
        try:
            # Generate QR code
            qr_code = qrcode.make(text)
            
            # Convert to bytes
            img_buffer = io.BytesIO()
            qr_code.save(img_buffer, format='PNG')
            img_buffer.seek(0)
            
            await ctx.send(f"> **QR Code for:** `{text[:50]}{'...' if len(text) > 50 else ''}`", 
                          file=discord.File(img_buffer, "qr_code.png"))
            
        except Exception as e:
            log_error(f"QR code generation error: {e}")
            await ctx.send("> **[ERROR]**: Failed to generate QR code", delete_after=5)
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), "qr")
    
    @commands.command()
    async def pingweb(self, ctx, url: str = None):
        """Ping a website and check status"""
        await ctx.message.delete()
        
        if not url:
            await ctx.send("> **[ERROR]**: Please provide a URL\n> **Usage:** `pingweb <url>`", delete_after=5)
            return
        
        # Add protocol if missing
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url
        
        try:
            response = requests.get(url, timeout=10, allow_redirects=True)
            status_code = response.status_code
            response_time = response.elapsed.total_seconds() * 1000
            
            if status_code == 200:
                status_text = "**🟢 Online**"
            elif 300 <= status_code < 400:
                status_text = "**🟡 Redirected**"
            elif 400 <= status_code < 500:
                status_text = "**🔴 Client Error**"
            elif 500 <= status_code < 600:
                status_text = "**🔴 Server Error**"
            else:
                status_text = "**⚪ Unknown**"
            
            await ctx.send(f"> **Website Status:** {status_text}\n> **Status Code:** `{status_code}`\n> **Response Time:** `{response_time:.2f}ms`\n> **URL:** {url}")
            
        except requests.RequestException as e:
            await ctx.send(f"> **🔴 Website Down**\n> **Error:** `{str(e)}`\n> **URL:** {url}")
        except Exception as e:
            log_error(f"Website ping error: {e}")
            await ctx.send("> **[ERROR]**: Failed to ping website", delete_after=5)
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), f"pingweb {url}")
    
    @commands.command()
    async def gentoken(self, ctx, user: discord.User = None):
        """Generate a fake Discord token"""
        await ctx.message.delete()
        
        # Generate fake token with proper format
        user_id_part = "ODA" + random.choice(string.ascii_letters)
        random_part1 = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(20))
        timestamp_part = random.choice(string.ascii_letters).upper() + ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(5))
        signature_part = ''.join(random.choice(string.ascii_letters + string.digits + '-_') for _ in range(27))
        
        fake_token = f"{user_id_part}{random_part1}.{timestamp_part}.{signature_part}"
        
        if user:
            await ctx.send(f"> **{user.display_name}'s** fake token: ||`{fake_token}`||")
        else:
            await ctx.send(f"> **Fake Token:** ||`{fake_token}`||\n> **Note:** This is a fake token for demonstration purposes only")
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), "gentoken")
    
    @commands.command()
    async def reverse(self, ctx, *, text: str = None):
        """Reverse text"""
        await ctx.message.delete()
        
        if not text:
            await ctx.send("> **[ERROR]**: Please provide text to reverse\n> **Usage:** `reverse <text>`", delete_after=5)
            return
        
        reversed_text = text[::-1]
        await ctx.send(f"> **Original:** {text}\n> **Reversed:** {reversed_text}")
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), "reverse")
    
    @commands.command()
    async def hidemention(self, ctx, display_text: str = None, *, hidden_text: str = None):
        """Hide text within other text using invisible characters"""
        await ctx.message.delete()
        
        if not display_text or not hidden_text:
            await ctx.send("> **[ERROR]**: Please provide both display and hidden text\n> **Usage:** `hidemention <display_text> <hidden_text>`", delete_after=5)
            return
        
        # Use zero-width characters to hide text
        zero_width_chars = '\u200b\u200c\u200d\u2060'
        
        # Convert hidden text to binary and use zero-width chars
        hidden_binary = ''.join(format(ord(char), '08b') for char in hidden_text)
        zero_width_text = ''.join(zero_width_chars[int(bit)] if bit.isdigit() else bit for bit in hidden_binary)
        
        result = f"{display_text}{zero_width_text}"
        
        await ctx.send(f"> **Hidden Message Created**\n```{result}```\n> **Display:** {display_text}\n> **Hidden:** {hidden_text}")
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), "hidemention")
    
    @commands.command()
    async def ascii(self, ctx, *, text: str = None):
        """Convert text to ASCII art"""
        await ctx.message.delete()
        
        if not text:
            await ctx.send("> **[ERROR]**: Please provide text to convert\n> **Usage:** `ascii <text>`", delete_after=5)
            return
        
        if len(text) > 20:
            await ctx.send("> **[ERROR]**: Text must be 20 characters or less", delete_after=5)
            return
        
        try:
            ascii_art = pyfiglet.figlet_format(text, font='slant')
            
            # Split into chunks if too long
            if len(ascii_art) > 1900:
                chunks = [ascii_art[i:i+1900] for i in range(0, len(ascii_art), 1900)]
                for chunk in chunks:
                    await ctx.send(f"```{chunk}```")
            else:
                await ctx.send(f"```{ascii_art}```")
                
        except Exception as e:
            log_error(f"ASCII art error: {e}")
            await ctx.send("> **[ERROR]**: Failed to generate ASCII art", delete_after=5)
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), "ascii")
    
    @commands.command()
    async def hypesquad(self, ctx, house: str = None):
        """Change HypeSquad house badge"""
        await ctx.message.delete()
        
        if not house:
            await ctx.send("> **[ERROR]**: Please specify a house\n> **Usage:** `hypesquad <bravery|brilliance|balance>`", delete_after=5)
            return
        
        house = house.lower()
        house_ids = {
            'bravery': 1,
            'brilliance': 2, 
            'balance': 3
        }
        
        if house not in house_ids:
            await ctx.send("> **[ERROR]**: Invalid house. Choose: `bravery`, `brilliance`, or `balance`", delete_after=5)
            return
        
        try:
            # This would require direct API calls to change HypeSquad
            # For security reasons, we'll just show what it would do
            await ctx.send(f"> **HypeSquad house would be changed to:** {house.title()}\n> **Note:** This feature requires additional API implementation for safety")
            
        except Exception as e:
            log_error(f"HypeSquad change error: {e}")
            await ctx.send("> **[ERROR]**: Failed to change HypeSquad house", delete_after=5)
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), f"hypesquad {house}")
    
    @commands.command()
    async def nitro(self, ctx):
        """Generate a fake Nitro code"""
        await ctx.message.delete()
        
        # Generate fake Nitro code with proper format
        fake_code = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(24))
        
        await ctx.send(f"> **Fake Nitro Code:** ||`{fake_code}`||\n> **Note:** This is a fake code for demonstration purposes only")
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), "nitro")
