"""
Fun and entertainment commands for the Discord SelfBot
Includes games, jokes, and various entertainment features
"""

import discord
from discord.ext import commands
import random
import asyncio
from utils.logger import log_error, get_command_logger

class FunCommands(commands.Cog):
    """Fun and entertainment commands"""
    
    def __init__(self, bot, config, selfbot_instance):
        self.bot = bot
        self.config = config
        self.selfbot = selfbot_instance
        self.command_logger = get_command_logger()
    
    @commands.command()
    async def playing(self, ctx, *, status: str = None):
        """Set playing status"""
        await ctx.message.delete()
        
        if not status:
            await ctx.send("> **[ERROR]**: Please provide a status\n> **Usage:** `playing <status>`", delete_after=5)
            return
        
        try:
            activity = discord.Game(name=status)
            await self.bot.change_presence(activity=activity)
            await ctx.send(f"> **Status set to:** Playing {status}")
            
        except Exception as e:
            log_error(f"Status change error: {e}")
            await ctx.send("> **[ERROR]**: Failed to change status", delete_after=5)
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), f"playing {status}")
    
    @commands.command()
    async def watching(self, ctx, *, status: str = None):
        """Set watching status"""
        await ctx.message.delete()
        
        if not status:
            await ctx.send("> **[ERROR]**: Please provide a status\n> **Usage:** `watching <status>`", delete_after=5)
            return
        
        try:
            activity = discord.Activity(type=discord.ActivityType.watching, name=status)
            await self.bot.change_presence(activity=activity)
            await ctx.send(f"> **Status set to:** Watching {status}")
            
        except Exception as e:
            log_error(f"Status change error: {e}")
            await ctx.send("> **[ERROR]**: Failed to change status", delete_after=5)
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), f"watching {status}")
    
    @commands.command()
    async def stopactivity(self, ctx):
        """Clear activity status"""
        await ctx.message.delete()
        
        try:
            await self.bot.change_presence(activity=None)
            await ctx.send("> **Activity status cleared**")
            
        except Exception as e:
            log_error(f"Status clear error: {e}")
            await ctx.send("> **[ERROR]**: Failed to clear status", delete_after=5)
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), "stopactivity")
    
    @commands.command()
    async def dick(self, ctx, user: discord.User = None):
        """Generate random size for user"""
        await ctx.message.delete()
        
        if not user:
            user = ctx.author
        
        # Generate "random" size based on user ID for consistency
        random.seed(user.id)
        size = random.randint(1, 30)
        
        size_bar = "8" + "=" * size + "D"
        
        await ctx.send(f"> **{user.display_name}'s size:** {size}cm\n> `{size_bar}`")
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), "dick")
    
    @commands.command()
    async def minesweeper(self, ctx, width: int = 9, height: int = 9):
        """Generate a minesweeper game"""
        await ctx.message.delete()
        
        if width < 3 or width > 13 or height < 3 or height > 13:
            await ctx.send("> **[ERROR]**: Grid size must be between 3x3 and 13x13", delete_after=5)
            return
        
        try:
            # Calculate number of mines (about 20% of grid)
            total_cells = width * height
            mine_count = max(1, total_cells // 5)
            
            # Create grid
            grid = [[0 for _ in range(width)] for _ in range(height)]
            
            # Place mines randomly
            mines_placed = 0
            while mines_placed < mine_count:
                x, y = random.randint(0, height-1), random.randint(0, width-1)
                if grid[x][y] != -1:  # -1 represents mine
                    grid[x][y] = -1
                    mines_placed += 1
            
            # Calculate numbers around mines
            directions = [(-1,-1), (-1,0), (-1,1), (0,-1), (0,1), (1,-1), (1,0), (1,1)]
            
            for i in range(height):
                for j in range(width):
                    if grid[i][j] != -1:
                        count = 0
                        for di, dj in directions:
                            ni, nj = i + di, j + dj
                            if 0 <= ni < height and 0 <= nj < width and grid[ni][nj] == -1:
                                count += 1
                        grid[i][j] = count
            
            # Convert to Discord spoiler format
            number_emojis = ["⬜", "1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣"]
            
            result = f"> **Minesweeper {width}x{height} ({mine_count} mines)**\n"
            
            for row in grid:
                line = ""
                for cell in row:
                    if cell == -1:
                        line += "||💣||"
                    else:
                        line += f"||{number_emojis[cell]}||"
                result += line + "\n"
            
            await ctx.send(result)
            
        except Exception as e:
            log_error(f"Minesweeper generation error: {e}")
            await ctx.send("> **[ERROR]**: Failed to generate minesweeper", delete_after=5)
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), f"minesweeper {width}x{height}")
    
    @commands.command()
    async def leetpeek(self, ctx, *, text: str = None):
        """Convert text to leet speak"""
        await ctx.message.delete()
        
        if not text:
            await ctx.send("> **[ERROR]**: Please provide text to convert\n> **Usage:** `leetpeek <text>`", delete_after=5)
            return
        
        # Leet speak conversion table
        leet_dict = {
            'a': '4', 'A': '4',
            'e': '3', 'E': '3',
            'i': '1', 'I': '1',
            'o': '0', 'O': '0',
            's': '5', 'S': '5',
            't': '7', 'T': '7',
            'l': '1', 'L': '1',
            'g': '9', 'G': '9',
            'b': '6', 'B': '6'
        }
        
        leet_text = ''.join(leet_dict.get(char, char) for char in text)
        
        await ctx.send(f"> **Original:** {text}\n> **L33t:** {leet_text}")
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), "leetpeek")
    
    @commands.command()
    async def airplane(self, ctx):
        """Send airplane ASCII art"""
        await ctx.message.delete()
        
        airplane_art = """
                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢀⠔⠢⡀⠀⠀⠀⠀⠀
                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡰⠁⠈⢣⠀⠀⠀⠀⠀
                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠃⠀⠀⠀⠘⡄⠀⠀⠀⠀
                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡜⠀⠀⠀⠀⠀⢸⠀⠀⠀⠀
                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⠁⠀⠀⠀⠀⠀⠸⡀⠀⠀⠀
                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡎⠀⠀⠀⠀⠀⠀⠀⢧⠀⠀⠀
                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠀⠀⠀⠀⠀⠀⠀⠀⠸⡀⠀⠀
                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⢇⠀⠀
                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠀⠀
                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⡀⠀
                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢇⠀
                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡎⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠀
                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢰⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢇
                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡎⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸
                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸
                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
                          ⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢸⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
        ✈️ Airplane ASCII art"""
        
        await ctx.send(airplane_art)
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), "airplane")
