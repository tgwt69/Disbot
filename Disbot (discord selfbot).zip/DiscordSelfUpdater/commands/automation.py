"""
Automation commands for the Discord SelfBot
Includes AFK, autoreply, copycat, and other automated features
"""

import discord
from discord.ext import commands
import asyncio
import itertools
from utils.logger import log_info, log_error, get_command_logger

class AutomationCommands(commands.Cog):
    """Automation and bot-like functionality commands"""
    
    def __init__(self, bot, config, selfbot_instance):
        self.bot = bot
        self.config = config
        self.selfbot = selfbot_instance
        self.command_logger = get_command_logger()
    
    @commands.command()
    async def afk(self, ctx, status: str = None, *, message: str = None):
        """Toggle AFK mode with optional custom message"""
        await ctx.message.delete()
        
        if not status:
            current_status = "enabled" if self.config["afk"]["enabled"] else "disabled"
            await ctx.send(f"> **AFK mode is currently {current_status}**\n> **Usage:** `afk <ON|OFF> [custom_message]`", delete_after=5)
            return
        
        status = status.upper()
        
        if status == "ON":
            self.config["afk"]["enabled"] = True
            
            if message:
                self.config["afk"]["message"] = message
            
            self.selfbot.save_config()
            
            afk_msg = self.config["afk"]["message"]
            await ctx.send(f"> **AFK mode enabled** ✅\n> **Message:** {afk_msg}")
            log_info(f"AFK mode enabled by {ctx.author}")
            
        elif status == "OFF":
            self.config["afk"]["enabled"] = False
            self.selfbot.save_config()
            
            await ctx.send("> **AFK mode disabled** ❌")
            log_info(f"AFK mode disabled by {ctx.author}")
            
        else:
            await ctx.send("> **[ERROR]**: Invalid status. Use `ON` or `OFF`", delete_after=5)
            return
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), f"afk {status}")
    
    @commands.command()
    async def autoreply(self, ctx, status: str = None, target=None):
        """Toggle autoreply for channels or users"""
        await ctx.message.delete()
        
        if not status:
            channels = len(self.config["autoreply"]["channels"])
            users = len(self.config["autoreply"]["users"])
            await ctx.send(f"> **Autoreply Status:**\n> **Active Channels:** {channels}\n> **Active Users:** {users}\n> **Usage:** `autoreply <ON|OFF> [#channel|@user]`", delete_after=10)
            return
        
        status = status.upper()
        
        if status not in ["ON", "OFF"]:
            await ctx.send("> **[ERROR]**: Invalid status. Use `ON` or `OFF`", delete_after=5)
            return
        
        # If no target specified, use current channel
        if not target:
            target = ctx.channel
        
        # Handle channel target
        if isinstance(target, discord.TextChannel) or isinstance(target, discord.DMChannel):
            channel_id = str(target.id)
            
            if status == "ON":
                if channel_id not in self.config["autoreply"]["channels"]:
                    self.config["autoreply"]["channels"].append(channel_id)
                    self.selfbot.save_config()
                    await ctx.send(f"> **Autoreply enabled** for {target.mention if hasattr(target, 'mention') else 'this channel'}")
                else:
                    await ctx.send(f"> **Autoreply already enabled** for {target.mention if hasattr(target, 'mention') else 'this channel'}", delete_after=5)
            
            elif status == "OFF":
                if channel_id in self.config["autoreply"]["channels"]:
                    self.config["autoreply"]["channels"].remove(channel_id)
                    self.selfbot.save_config()
                    await ctx.send(f"> **Autoreply disabled** for {target.mention if hasattr(target, 'mention') else 'this channel'}")
                else:
                    await ctx.send(f"> **Autoreply not enabled** for {target.mention if hasattr(target, 'mention') else 'this channel'}", delete_after=5)
        
        # Handle user target
        elif isinstance(target, discord.User) or isinstance(target, discord.Member):
            user_id = str(target.id)
            
            if status == "ON":
                if user_id not in self.config["autoreply"]["users"]:
                    self.config["autoreply"]["users"].append(user_id)
                    self.selfbot.save_config()
                    await ctx.send(f"> **Autoreply enabled** for {target.mention}")
                else:
                    await ctx.send(f"> **Autoreply already enabled** for {target.mention}", delete_after=5)
            
            elif status == "OFF":
                if user_id in self.config["autoreply"]["users"]:
                    self.config["autoreply"]["users"].remove(user_id)
                    self.selfbot.save_config()
                    await ctx.send(f"> **Autoreply disabled** for {target.mention}")
                else:
                    await ctx.send(f"> **Autoreply not enabled** for {target.mention}", delete_after=5)
        
        else:
            await ctx.send("> **[ERROR]**: Invalid target. Mention a user or channel", delete_after=5)
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), f"autoreply {status}")
    
    @commands.command()
    async def copycat(self, ctx, status: str = None, user: discord.User = None):
        """Toggle copycat mode for a specific user"""
        await ctx.message.delete()
        
        if not status:
            copycat_users = len(self.config["copycat"]["users"])
            await ctx.send(f"> **Copycat Status:** {copycat_users} active users\n> **Usage:** `copycat <ON|OFF> @user`", delete_after=5)
            return
        
        if not user:
            await ctx.send("> **[ERROR]**: Please mention a user\n> **Usage:** `copycat <ON|OFF> @user`", delete_after=5)
            return
        
        status = status.upper()
        user_id = user.id
        
        if status == "ON":
            if user_id not in self.config["copycat"]["users"]:
                self.config["copycat"]["users"].append(user_id)
                self.selfbot.save_config()
                await ctx.send(f"> **Copycat enabled** for {user.mention} 🐱")
                log_info(f"Copycat enabled for {user} by {ctx.author}")
            else:
                await ctx.send(f"> **Copycat already enabled** for {user.mention}", delete_after=5)
        
        elif status == "OFF":
            if user_id in self.config["copycat"]["users"]:
                self.config["copycat"]["users"].remove(user_id)
                self.selfbot.save_config()
                await ctx.send(f"> **Copycat disabled** for {user.mention}")
                log_info(f"Copycat disabled for {user} by {ctx.author}")
            else:
                await ctx.send(f"> **Copycat not enabled** for {user.mention}", delete_after=5)
        
        else:
            await ctx.send("> **[ERROR]**: Invalid status. Use `ON` or `OFF`", delete_after=5)
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), f"copycat {status}")
    
    @commands.command()
    async def edit(self, ctx, *, message: str = None):
        """Send a message with the (edited) tag moved"""
        await ctx.message.delete()
        
        if not message:
            await ctx.send("> **[ERROR]**: Please provide a message\n> **Usage:** `edit <message>`", delete_after=5)
            return
        
        try:
            # Send message then edit it to move the (edited) tag
            sent_msg = await ctx.send("‎")  # Invisible character
            await sent_msg.edit(content=message)
            
        except Exception as e:
            log_error(f"Edit command error: {e}")
            await ctx.send("> **[ERROR]**: Failed to send edited message", delete_after=5)
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), "edit")
    
    @commands.command(aliases=['tinfo'])
    async def tokeninfo(self, ctx, token: str = None):
        """Analyze a Discord token (educational purposes only)"""
        await ctx.message.delete()
        
        if not token:
            await ctx.send("> **[ERROR]**: Please provide a token\n> **Usage:** `tokeninfo <token>`", delete_after=5)
            return
        
        try:
            # Basic token format validation
            parts = token.split('.')
            
            if len(parts) != 3:
                await ctx.send("> **[ERROR]**: Invalid token format", delete_after=5)
                return
            
            # Decode user ID from token (this is safe as it's just base64)
            import base64
            try:
                user_id_encoded = parts[0]
                # Add padding if needed
                padding = 4 - len(user_id_encoded) % 4
                if padding != 4:
                    user_id_encoded += '=' * padding
                
                user_id_bytes = base64.b64decode(user_id_encoded)
                user_id = int.from_bytes(user_id_bytes, 'big')
                
                # Calculate creation date
                discord_epoch = 1420070400000
                timestamp = ((user_id >> 22) + discord_epoch) / 1000
                
                import datetime
                creation_date = datetime.datetime.fromtimestamp(timestamp, tz=datetime.timezone.utc)
                
                info_text = f"""**Token Analysis (Educational Only)**\n
> :id: **User ID:** `{user_id}`
> :calendar: **Account Created:** {creation_date.strftime('%Y-%m-%d %H:%M:%S UTC')}
> :warning: **Token Parts:** {len(parts)} (Valid format)
> :closed_lock_with_key: **Note:** This is static analysis only - token not used for authentication"""
                
                await ctx.send(info_text)
                
            except Exception as decode_error:
                await ctx.send("> **[ERROR]**: Could not decode token information", delete_after=5)
        
        except Exception as e:
            log_error(f"Token info error: {e}")
            await ctx.send("> **[ERROR]**: Failed to analyze token", delete_after=5)
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), "tokeninfo")
