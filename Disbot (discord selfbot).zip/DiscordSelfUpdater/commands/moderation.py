"""
Moderation commands for the Discord SelfBot
Includes message management and server administration tools
"""

import discord
from discord.ext import commands
import asyncio
import requests
from utils.logger import log_info, log_error, log_warning, get_command_logger

class ModerationCommands(commands.Cog):
    """Moderation and administration commands"""
    
    def __init__(self, bot, config, selfbot_instance):
        self.bot = bot
        self.config = config
        self.selfbot = selfbot_instance
        self.command_logger = get_command_logger()
    
    @commands.command()
    async def purge(self, ctx, amount: int = None):
        """Delete a specified number of messages"""
        await ctx.message.delete()
        
        if not amount:
            await ctx.send("> **[ERROR]**: Please specify the number of messages to delete\n> **Usage:** `purge <amount>`", delete_after=5)
            return
        
        if amount <= 0 or amount > 100:
            await ctx.send("> **[ERROR]**: Amount must be between 1 and 100", delete_after=5)
            return
        
        try:
            # Check if we have permission to delete messages
            if not ctx.channel.permissions_for(ctx.guild.me).manage_messages:
                await ctx.send("> **[ERROR]**: No permission to delete messages in this channel", delete_after=5)
                return
            
            deleted = await ctx.channel.purge(limit=amount, check=lambda m: True)
            
            status_msg = await ctx.send(f"> **Deleted {len(deleted)} messages**")
            await asyncio.sleep(3)
            await status_msg.delete()
            
            log_info(f"Purged {len(deleted)} messages in {ctx.channel} by {ctx.author}")
            
        except discord.Forbidden:
            await ctx.send("> **[ERROR]**: No permission to delete messages", delete_after=5)
        except discord.HTTPException as e:
            await ctx.send(f"> **[ERROR]**: Failed to delete messages: {str(e)}", delete_after=5)
        except Exception as e:
            log_error(f"Purge command error: {e}")
            await ctx.send("> **[ERROR]**: An unexpected error occurred", delete_after=5)
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), f"purge {amount}")
    
    @commands.command()
    async def clear(self, ctx):
        """Clear messages from the current channel"""
        await ctx.message.delete()
        
        try:
            if not ctx.channel.permissions_for(ctx.guild.me).manage_messages:
                await ctx.send("> **[ERROR]**: No permission to delete messages in this channel", delete_after=5)
                return
            
            deleted = await ctx.channel.purge(limit=100)
            
            status_msg = await ctx.send(f"> **Cleared {len(deleted)} messages from channel**")
            await asyncio.sleep(3)
            await status_msg.delete()
            
            log_info(f"Cleared {len(deleted)} messages from {ctx.channel} by {ctx.author}")
            
        except discord.Forbidden:
            await ctx.send("> **[ERROR]**: No permission to clear messages", delete_after=5)
        except Exception as e:
            log_error(f"Clear command error: {e}")
            await ctx.send("> **[ERROR]**: Failed to clear messages", delete_after=5)
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), "clear")
    
    @commands.command()
    async def cleardm(self, ctx, amount: int = None):
        """Clear DM messages with a user"""
        await ctx.message.delete()
        
        if not isinstance(ctx.channel, discord.DMChannel):
            await ctx.send("> **[ERROR]**: This command only works in DMs", delete_after=5)
            return
        
        if not amount:
            amount = 50
        
        if amount <= 0 or amount > 100:
            await ctx.send("> **[ERROR]**: Amount must be between 1 and 100", delete_after=5)
            return
        
        try:
            deleted_count = 0
            async for message in ctx.channel.history(limit=amount):
                if message.author == self.bot.user:
                    await message.delete()
                    deleted_count += 1
                    await asyncio.sleep(0.5)  # Rate limiting
            
            await ctx.send(f"> **Deleted {deleted_count} of your messages**", delete_after=3)
            log_info(f"Cleared {deleted_count} DM messages by {ctx.author}")
            
        except Exception as e:
            log_error(f"Clear DM command error: {e}")
            await ctx.send("> **[ERROR]**: Failed to clear DM messages", delete_after=5)
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), f"cleardm {amount}")
    
    @commands.command()
    async def spam(self, ctx, amount: int = None, *, message: str = None):
        """Spam a message multiple times"""
        await ctx.message.delete()
        
        if not amount or not message:
            await ctx.send("> **[ERROR]**: Please provide amount and message\n> **Usage:** `spam <amount> <message>`", delete_after=5)
            return
        
        if amount <= 0 or amount > 20:
            await ctx.send("> **[ERROR]**: Amount must be between 1 and 20", delete_after=5)
            return
        
        if len(message) > 500:
            await ctx.send("> **[ERROR]**: Message must be 500 characters or less", delete_after=5)
            return
        
        try:
            for i in range(amount):
                await ctx.send(message)
                await asyncio.sleep(1)  # Rate limiting
            
            log_warning(f"Spam command used: {amount} messages by {ctx.author}")
            
        except discord.HTTPException as e:
            await ctx.send(f"> **[ERROR]**: Failed to send messages: {str(e)}", delete_after=5)
        except Exception as e:
            log_error(f"Spam command error: {e}")
            await ctx.send("> **[ERROR]**: An unexpected error occurred", delete_after=5)
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), f"spam {amount}")
    
    @commands.command()
    async def quickdelete(self, ctx, *, message: str = None):
        """Send a message and delete it after 2 seconds"""
        await ctx.message.delete()
        
        if not message:
            await ctx.send("> **[ERROR]**: Please provide a message\n> **Usage:** `quickdelete <message>`", delete_after=2)
            return
        
        try:
            sent_message = await ctx.send(message)
            await asyncio.sleep(2)
            await sent_message.delete()
            
        except Exception as e:
            log_error(f"Quick delete command error: {e}")
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), "quickdelete")
    
    @commands.command()
    async def whremove(self, ctx, webhook_url: str = None):
        """Remove a webhook"""
        await ctx.message.delete()
        
        if not webhook_url:
            await ctx.send("> **[ERROR]**: Please provide a webhook URL\n> **Usage:** `whremove <webhook_url>`", delete_after=5)
            return
        
        try:
            response = requests.delete(webhook_url, timeout=10)
            
            if response.status_code == 204:
                await ctx.send("> **Webhook removed successfully** ✅")
            elif response.status_code == 404:
                await ctx.send("> **[ERROR]**: Webhook not found", delete_after=5)
            elif response.status_code == 403:
                await ctx.send("> **[ERROR]**: No permission to delete webhook", delete_after=5)
            else:
                await ctx.send(f"> **[ERROR]**: Failed to remove webhook (Status: {response.status_code})", delete_after=5)
            
            log_info(f"Webhook removal attempted by {ctx.author}: {webhook_url}")
            
        except requests.RequestException as e:
            await ctx.send(f"> **[ERROR]**: Failed to remove webhook: {str(e)}", delete_after=5)
        except Exception as e:
            log_error(f"Webhook removal error: {e}")
            await ctx.send("> **[ERROR]**: An unexpected error occurred", delete_after=5)
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), "whremove")
    
    @commands.command()
    async def fetchmembers(self, ctx):
        """Fetch all members in the server"""
        await ctx.message.delete()
        
        if not ctx.guild:
            await ctx.send("> **[ERROR]**: This command only works in servers", delete_after=5)
            return
        
        try:
            # Request all members if not cached
            if not ctx.guild.chunked:
                await ctx.guild.chunk()
            
            members = ctx.guild.members
            member_count = len(members)
            
            # Create member list (limit to avoid spam)
            member_list = []
            for i, member in enumerate(members[:20]):  # Show first 20 members
                status = "🟢" if member.status == discord.Status.online else "🔴"
                member_list.append(f"{status} {member.display_name} (`{member.id}`)")
            
            result = f"> **Server Members ({member_count} total):**\n" + "\n".join(member_list)
            
            if member_count > 20:
                result += f"\n... and {member_count - 20} more members"
            
            await ctx.send(result)
            log_info(f"Fetched {member_count} members for {ctx.author}")
            
        except Exception as e:
            log_error(f"Fetch members error: {e}")
            await ctx.send("> **[ERROR]**: Failed to fetch members", delete_after=5)
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), "fetchmembers")
    
    @commands.command()
    async def dmall(self, ctx, *, message: str = None):
        """Send a DM to all server members"""
        await ctx.message.delete()
        
        if not ctx.guild:
            await ctx.send("> **[ERROR]**: This command only works in servers", delete_after=5)
            return
        
        if not message:
            await ctx.send("> **[ERROR]**: Please provide a message\n> **Usage:** `dmall <message>`", delete_after=5)
            return
        
        # Safety check
        confirmation = await ctx.send("> **⚠️ WARNING**: This will DM all server members. Type `CONFIRM` to proceed or anything else to cancel.")
        
        try:
            response = await self.bot.wait_for(
                'message',
                check=lambda m: m.author == ctx.author and m.channel == ctx.channel,
                timeout=30.0
            )
            
            await response.delete()
            await confirmation.delete()
            
            if response.content.upper() != 'CONFIRM':
                await ctx.send("> **Operation cancelled**", delete_after=3)
                return
            
        except asyncio.TimeoutError:
            await confirmation.delete()
            await ctx.send("> **Operation cancelled (timeout)**", delete_after=3)
            return
        
        try:
            if not ctx.guild.chunked:
                await ctx.guild.chunk()
            
            members = [m for m in ctx.guild.members if not m.bot and m != self.bot.user]
            sent_count = 0
            failed_count = 0
            
            status_msg = await ctx.send(f"> **Sending DMs...** (0/{len(members)})")
            
            for member in members:
                try:
                    await member.send(message)
                    sent_count += 1
                    
                    # Update status every 10 messages
                    if sent_count % 10 == 0:
                        await status_msg.edit(content=f"> **Sending DMs...** ({sent_count}/{len(members)})")
                    
                    await asyncio.sleep(2)  # Rate limiting
                    
                except:
                    failed_count += 1
            
            await status_msg.edit(content=f"> **DM complete:** Sent to {sent_count} members, {failed_count} failed")
            log_warning(f"Mass DM sent by {ctx.author}: {sent_count} successful, {failed_count} failed")
            
        except Exception as e:
            log_error(f"DM all error: {e}")
            await ctx.send("> **[ERROR]**: Failed to send DMs", delete_after=5)
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), "dmall")
    
    @commands.command()
    async def sendall(self, ctx, *, message: str = None):
        """Send a message to all channels in the server"""
        await ctx.message.delete()
        
        if not ctx.guild:
            await ctx.send("> **[ERROR]**: This command only works in servers", delete_after=5)
            return
        
        if not message:
            await ctx.send("> **[ERROR]**: Please provide a message\n> **Usage:** `sendall <message>`", delete_after=5)
            return
        
        try:
            text_channels = [ch for ch in ctx.guild.text_channels if ch.permissions_for(ctx.guild.me).send_messages]
            sent_count = 0
            
            for channel in text_channels:
                try:
                    await channel.send(message)
                    sent_count += 1
                    await asyncio.sleep(1)  # Rate limiting
                except:
                    pass
            
            await ctx.send(f"> **Message sent to {sent_count} channels**", delete_after=5)
            log_warning(f"Mass message sent by {ctx.author} to {sent_count} channels")
            
        except Exception as e:
            log_error(f"Send all error: {e}")
            await ctx.send("> **[ERROR]**: Failed to send messages", delete_after=5)
        
        self.command_logger.log_command(ctx.author.id, str(ctx.author), "sendall")
