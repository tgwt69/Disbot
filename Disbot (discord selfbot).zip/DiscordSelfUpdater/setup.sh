#!/bin/bash

echo "================================================"
echo "   Discord SelfBot v3.0 - 2025 Edition Setup"
echo "   Updated for discord.py-self 2.0.1 compatibility"
echo "================================================"
echo

# Check if Python 3 is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Error: Python 3 is not installed!"
    echo "Please install Python 3.8+ first"
    exit 1
fi

echo "✅ Python 3 found. Running setup script..."
python3 setup.py

echo
echo "✅ Setup complete! You can now run the selfbot with:"
echo "- ./start.sh"
echo "- python3 main.py"
echo
