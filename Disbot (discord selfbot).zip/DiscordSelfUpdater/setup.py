#!/usr/bin/env python3
"""
Setup script for Discord SelfBot v3.0
Automated installation and configuration
"""

import os
import sys
import subprocess
import platform
import json
import urllib.request
from pathlib import Path

def print_banner():
    """Print setup banner"""
    print("\n" + "="*60)
    print("   Discord SelfBot v3.0 - 2025 Edition Setup")
    print("   Updated for discord.py-self 2.0.1 compatibility")
    print("="*60 + "\n")

def check_python_version():
    """Check if Python version is compatible"""
    if sys.version_info < (3, 8):
        print("❌ Error: Python 3.8 or higher is required!")
        print(f"Current version: {sys.version}")
        sys.exit(1)
    print(f"✅ Python version {sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro} is compatible")

def install_requirements():
    """Install required packages"""
    print("\n📦 Installing required packages...")
    
    packages = [
        "discord.py-self==2.0.1",
        "requests",
        "colorama", 
        "gtts",
        "qrcode[pil]",
        "pyfiglet"
    ]
    
    for package in packages:
        try:
            print(f"Installing {package}...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", package], 
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            print(f"✅ {package} installed successfully")
        except subprocess.CalledProcessError:
            print(f"❌ Failed to install {package}")
            return False
    
    return True

def create_directories():
    """Create necessary directories"""
    print("\n📁 Creating directories...")
    
    directories = ["config", "logs", "utils", "commands"]
    
    for directory in directories:
        Path(directory).mkdir(exist_ok=True)
        print(f"✅ Created directory: {directory}")

def setup_config():
    """Setup configuration file"""
    print("\n⚙️ Setting up configuration...")
    
    config_path = Path("config/config.json")
    
    if config_path.exists():
        print("⚠️ Configuration file already exists")
        overwrite = input("Do you want to overwrite it? (y/N): ").lower().strip()
        if overwrite != 'y':
            print("✅ Keeping existing configuration")
            return
    
    # Get user token
    print("\n🔑 Discord User Token Setup")
    print("To get your Discord user token:")
    print("1. Open Discord in your browser")
    print("2. Press F12 to open Developer Tools")
    print("3. Go to Network tab")
    print("4. Refresh the page (F5)")
    print("5. Look for any request and check the Authorization header")
    print("6. Copy the token (without 'Bearer ' prefix)")
    print("\n⚠️ WARNING: Never share your token with anyone!")
    
    token = input("\nEnter your Discord user token (or press Enter to set later): ").strip()
    if not token:
        token = "YOUR_USER_TOKEN_HERE"
    
    # Get prefix
    prefix = input("Enter command prefix (default: *): ").strip()
    if not prefix:
        prefix = "*"
    
    config = {
        "token": token,
        "prefix": prefix,
        "remote-users": [],
        "autoreply": {
            "messages": [
                "https://github.com/AstraaDev/Discord-SelfBot",
                "Check out this amazing selfbot project!",
                "Discord SelfBot v3.0 - 2025 Edition"
            ],
            "channels": [],
            "users": []
        },
        "afk": {
            "enabled": False,
            "message": "I am currently AFK. I will respond as soon as possible!"
        },
        "copycat": {
            "users": []
        },
        "logging": {
            "level": "INFO",
            "file": "selfbot.log",
            "console": True
        },
        "rate_limiting": {
            "enabled": True,
            "max_commands_per_minute": 30,
            "burst_limit": 5
        },
        "security": {
            "auto_delete_commands": False,
            "restricted_guilds": [],
            "safe_mode": True
        }
    }
    
    with open(config_path, 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=4)
    
    print("✅ Configuration file created")

def create_launcher():
    """Create platform-specific launcher scripts"""
    print("\n🚀 Creating launcher scripts...")
    
    # Windows batch file
    with open("start.bat", "w") as f:
        f.write("""@echo off
title Discord SelfBot v3.0 - 2025 Edition
cd /d "%~dp0"
python main.py
pause
""")
    print("✅ Created start.bat for Windows")
    
    # Unix shell script
    with open("start.sh", "w") as f:
        f.write("""#!/bin/bash
cd "$(dirname "$0")"
python3 main.py
""")
    
    # Make shell script executable on Unix systems
    if platform.system() != "Windows":
        os.chmod("start.sh", 0o755)
    print("✅ Created start.sh for Unix/Linux")

def main():
    """Main setup function"""
    print_banner()
    
    try:
        # Check Python version
        check_python_version()
        
        # Create directories
        create_directories()
        
        # Install requirements
        if not install_requirements():
            print("\n❌ Failed to install some packages. Please install manually:")
            print("pip install discord.py-self==2.0.1 requests colorama gtts qrcode pyfiglet")
            return
        
        # Setup configuration
        setup_config()
        
        # Create launcher scripts
        create_launcher()
        
        print("\n" + "="*60)
        print("✅ Setup completed successfully!")
        print("\nNext steps:")
        print("1. Edit config/config.json and add your Discord token")
        print("2. Run the selfbot:")
        if platform.system() == "Windows":
            print("   - Double-click start.bat")
            print("   - Or run: python main.py")
        else:
            print("   - Run: ./start.sh")
            print("   - Or run: python3 main.py")
        print("\n⚠️ Remember: Selfbots violate Discord ToS. Use at your own risk!")
        print("="*60)
        
    except KeyboardInterrupt:
        print("\n❌ Setup cancelled by user")
    except Exception as e:
        print(f"\n❌ Setup failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
