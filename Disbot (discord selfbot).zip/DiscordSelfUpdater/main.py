#!/usr/bin/env python3
"""
Discord SelfBot v3.0 - 2025 Edition
Updated for discord.py-self 2.0.1 compatibility
"""

import discord
from discord.ext import commands
import asyncio
import json
import os
import platform
import datetime
import traceback
from colorama import Fore, init
import ctypes
import sys

# Import custom modules
from utils.logger import setup_logger, log_info, log_error, log_warning
from utils.rate_limiter import RateLimiter
from commands.core import CoreCommands
from commands.utility import UtilityCommands  
from commands.moderation import ModerationCommands
from commands.fun import FunCommands
from commands.automation import AutomationCommands

# Initialize colorama for cross-platform colored output
init()

# Version info
__version__ = "3.0"
__release_date__ = "2025-07-01"

# Color constants
y = Fore.LIGHTYELLOW_EX
b = Fore.LIGHTBLUE_EX
w = Fore.LIGHTWHITE_EX
g = Fore.LIGHTGREEN_EX
r = Fore.LIGHTRED_EX

class SelfBot:
    """Main SelfBot class handling initialization and core functionality"""
    
    def __init__(self):
        self.start_time = datetime.datetime.now(datetime.timezone.utc)
        self.config = self.load_config()
        self.rate_limiter = RateLimiter()
        self.logger = setup_logger()
        
        # Initialize bot with discord.py-self 2.0.1 parameters
        # Note: discord.py-self doesn't use Intents the same way as regular discord.py
        self.bot = commands.Bot(
            command_prefix=self.get_prefix,
            description='Discord SelfBot v3.0 - 2025 Edition',
            self_bot=True,
            help_command=None,
            case_insensitive=True
        )
        
        self.setup_events()
    
    def load_config(self):
        """Load configuration from config.json"""
        try:
            config_path = os.path.join("config", "config.json")
            if not os.path.exists(config_path):
                self.create_default_config()
            
            with open(config_path, "r", encoding="utf-8") as file:
                config = json.load(file)
                
            # Validate required keys
            required_keys = ["token", "prefix", "remote-users", "autoreply", "afk", "copycat"]
            for key in required_keys:
                if key not in config:
                    log_error(f"Missing required config key: {key}")
                    sys.exit(1)
                    
            return config
        except Exception as e:
            log_error(f"Failed to load config: {e}")
            sys.exit(1)
    
    def create_default_config(self):
        """Create default configuration file"""
        os.makedirs("config", exist_ok=True)
        
        default_config = {
            "token": "YOUR_USER_TOKEN_HERE",
            "prefix": "*",
            "remote-users": [],
            "autoreply": {
                "messages": [
                    "https://github.com/AstraaDev/Discord-SelfBot",
                    "Check out this amazing selfbot!"
                ],
                "channels": [],
                "users": []
            },
            "afk": {
                "enabled": False,
                "message": "I am currently AFK. I will respond as soon as possible!"
            },
            "copycat": {
                "users": []
            },
            "logging": {
                "level": "INFO",
                "file": "selfbot.log"
            }
        }
        
        config_path = os.path.join("config", "config.json")
        with open(config_path, "w", encoding="utf-8") as file:
            json.dump(default_config, file, indent=4)
        
        log_info("Created default config.json. Please edit it with your token and preferences.")
    
    def save_config(self):
        """Save current configuration to file"""
        try:
            config_path = os.path.join("config", "config.json")
            with open(config_path, "w", encoding="utf-8") as file:
                json.dump(self.config, file, indent=4)
        except Exception as e:
            log_error(f"Failed to save config: {e}")
    
    async def get_prefix(self, bot, message):
        """Dynamic prefix getter"""
        return self.config.get("prefix", "*")
    
    def setup_events(self):
        """Setup bot events"""
        
        @self.bot.event
        async def on_ready():
            """Called when bot is ready"""
            await self.on_ready()
        
        @self.bot.event
        async def on_message(message):
            """Handle incoming messages"""
            await self.on_message(message)
        
        @self.bot.event
        async def on_command_error(ctx, error):
            """Handle command errors"""
            await self.on_command_error(ctx, error)
        
        @self.bot.event
        async def on_error(event, *args, **kwargs):
            """Handle general errors"""
            log_error(f"Error in event {event}: {traceback.format_exc()}")
    
    async def on_ready(self):
        """Bot ready event handler"""
        if platform.system() == "Windows":
            try:
                ctypes.windll.kernel32.SetConsoleTitleW(f"SelfBot v{__version__} - {self.bot.user}")
                os.system('cls')
            except:
                pass
        else:
            os.system('clear')
        
        # Load commands after bot is ready
        await self.load_commands()
        
        self.display_banner()
        log_info(f"SelfBot v{__version__} ready! Logged in as {self.bot.user}")
    
    async def on_message(self, message):
        """Message event handler with automation features"""
        # Skip if message is from a bot or webhook
        if message.author.bot:
            return
        
        # Handle copycat functionality
        if message.author.id in self.config["copycat"]["users"]:
            await self.handle_copycat(message)
            return
        
        # Handle AFK functionality
        if self.config["afk"]["enabled"]:
            await self.handle_afk(message)
        
        # Handle autoreply functionality
        if message.author != self.bot.user:
            await self.handle_autoreply(message)
        
        # Process commands only from authorized users
        if message.author == self.bot.user or str(message.author.id) in self.config["remote-users"]:
            # Rate limiting check
            if not await self.rate_limiter.check_rate_limit(message.author.id):
                return
            
            await self.bot.process_commands(message)
    
    async def handle_copycat(self, message):
        """Handle copycat functionality"""
        try:
            if message.content.startswith(self.config['prefix']):
                response_message = message.content[len(self.config['prefix']):]
                if response_message.strip():
                    await message.reply(response_message)
            else:
                if message.content.strip():
                    await message.reply(message.content)
        except discord.HTTPException as e:
            log_error(f"Failed to send copycat message: {e}")
        except Exception as e:
            log_error(f"Unexpected error in copycat: {e}")
    
    async def handle_afk(self, message):
        """Handle AFK functionality"""
        try:
            # Check if bot user was mentioned
            if self.bot.user in message.mentions and message.author != self.bot.user:
                await message.reply(self.config["afk"]["message"])
                return
            
            # Check if it's a DM
            if isinstance(message.channel, discord.DMChannel) and message.author != self.bot.user:
                await message.reply(self.config["afk"]["message"])
                return
        except discord.HTTPException as e:
            log_error(f"Failed to send AFK message: {e}")
        except Exception as e:
            log_error(f"Unexpected error in AFK handler: {e}")
    
    async def handle_autoreply(self, message):
        """Handle autoreply functionality"""
        try:
            import itertools
            
            # Initialize message generator if not exists
            if not hasattr(self, 'message_generator'):
                self.message_generator = itertools.cycle(self.config["autoreply"]["messages"])
            
            # Check if user is in autoreply users list
            if str(message.author.id) in self.config["autoreply"]["users"]:
                autoreply_message = next(self.message_generator)
                await message.reply(autoreply_message)
                return
            
            # Check if channel is in autoreply channels list
            if str(message.channel.id) in self.config["autoreply"]["channels"]:
                autoreply_message = next(self.message_generator)
                await message.reply(autoreply_message)
                return
        except discord.HTTPException as e:
            log_error(f"Failed to send autoreply message: {e}")
        except Exception as e:
            log_error(f"Unexpected error in autoreply: {e}")
    
    async def on_command_error(self, ctx, error):
        """Command error handler"""
        if isinstance(error, commands.CommandNotFound):
            return  # Ignore unknown commands
        elif isinstance(error, commands.MissingRequiredArgument):
            await ctx.send(f"> **[ERROR]**: Missing required argument: `{error.param.name}`", delete_after=5)
        elif isinstance(error, commands.BadArgument):
            await ctx.send(f"> **[ERROR]**: Invalid argument provided", delete_after=5)
        elif isinstance(error, discord.HTTPException):
            await ctx.send(f"> **[ERROR]**: Discord API error: {str(error)}", delete_after=5)
        else:
            log_error(f"Unhandled command error: {error}")
            await ctx.send(f"> **[ERROR]**: An unexpected error occurred", delete_after=5)
    
    async def load_commands(self):
        """Load all command modules"""
        try:
            # Add command cogs
            await self.bot.add_cog(CoreCommands(self.bot, self.config, self))
            await self.bot.add_cog(UtilityCommands(self.bot, self.config, self))
            await self.bot.add_cog(ModerationCommands(self.bot, self.config, self))
            await self.bot.add_cog(FunCommands(self.bot, self.config, self))
            await self.bot.add_cog(AutomationCommands(self.bot, self.config, self))
            
            log_info("Successfully loaded all command modules")
        except Exception as e:
            log_error(f"Failed to load commands: {e}")
    
    def display_banner(self):
        """Display the startup banner"""
        banner = f"""\n{Fore.RESET}
                        ██████╗ ████████╗██╗ ██████╗     ████████╗ ██████╗  ██████╗ ██╗
                       ██╔═══██╗╚══██╔══╝██║██╔═══██╗    ╚══██╔══╝██╔═══██╗██╔═══██╗██║
                       ██║██╗██║   ██║   ██║██║   ██║       ██║   ██║   ██║██║   ██║██║
                       ██║██║██║   ██║   ██║██║   ██║       ██║   ██║   ██║██║   ██║██║
                       ╚█║████╔╝   ██║   ██║╚██████╔╝       ██║   ╚██████╔╝╚██████╔╝███████╗
                        ╚╝╚═══╝    ╚═╝   ╚═╝ ╚═════╝        ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝\n""".replace('█', f'{b}█{y}')
        
        info_section = f"""{y}------------------------------------------------------------------------------------------------------------------------
{w}AstraaDev {b}|{w} https://github.com/AstraaDev {b}|{w} Discord SelfBot v{__version__} {b}|{w} 2025 Edition {b}|{w} discord.py-self 2.0.1
{y}------------------------------------------------------------------------------------------------------------------------\n"""
        
        # Get user info safely
        user_info = f"{self.bot.user} ({self.bot.user.id})" if self.bot.user else "Not logged in"
        
        stats_section = f"""{y}[{g}+{y}]{w} SelfBot Information:\n
\t{y}[{w}#{y}]{w} Version: v{__version__} ({__release_date__})
\t{y}[{w}#{y}]{w} Logged in as: {user_info}
\t{y}[{w}#{y}]{w} Cached Users: {len(self.bot.users)}
\t{y}[{w}#{y}]{w} Guilds Connected: {len(self.bot.guilds)}\n
{y}[{g}+{y}]{w} Settings Overview:\n
\t{y}[{w}#{y}]{w} SelfBot Prefix: {self.config.get('prefix', '*')}
\t{y}[{w}#{y}]{w} Remote Users Configured: {len(self.config.get('remote-users', []))}
\t{y}[{w}#{y}]{w} Active Autoreply Channels: {len(self.config.get('autoreply', {}).get('channels', []))}
\t{y}[{w}#{y}]{w} Active Autoreply Users: {len(self.config.get('autoreply', {}).get('users', []))}
\t{y}[{w}#{y}]{w} AFK Status: {'Enabled' if self.config.get('afk', {}).get('enabled', False) else 'Disabled'}
\t{y}[{w}#{y}]{w} Copycat Users: {len(self.config.get('copycat', {}).get('users', []))}\n
{y}[{g}!{y}]{w} SelfBot is now online and ready!"""
        
        print(banner + info_section + stats_section)
    
    async def run(self):
        """Start the bot"""
        try:
            token = self.config.get("token")
            if not token or token == "YOUR_USER_TOKEN_HERE":
                log_error("Please set your Discord user token in config/config.json")
                return
            
            log_info("Starting SelfBot...")
            await self.bot.start(token)  # discord.py-self doesn't need bot=False parameter
            
        except discord.LoginFailure:
            log_error("Invalid token provided. Please check your token in config/config.json")
        except discord.HTTPException as e:
            log_error(f"HTTP Exception: {e}")
        except Exception as e:
            log_error(f"Failed to start bot: {e}")

def main():
    """Main entry point"""
    try:
        # Check Python version
        if sys.version_info < (3, 8):
            print(f"{r}[ERROR]{w} Python 3.8 or higher is required!")
            sys.exit(1)
        
        # Initialize and run the selfbot
        selfbot = SelfBot()
        
        # Handle platform-specific event loop setup
        if platform.system() == "Windows":
            # Set up proper event loop policy for Windows
            try:
                asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())
            except AttributeError:
                # Fallback for older Python versions
                pass
        
        # Run the bot
        asyncio.run(selfbot.run())
        
    except KeyboardInterrupt:
        log_info("SelfBot stopped by user")
    except Exception as e:
        log_error(f"Critical error: {e}")
        traceback.print_exc()

if __name__ == "__main__":
    main()
